package dodger;

import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.File;

import javax.imageio.ImageIO;
import javax.swing.JFrame;




public class BirdImage {
	
	private BufferedImage img = null;
	private static int bird_dia= 36;
	// Setting x co-ordinate for bird:
	public static int x = (GamePanel.WIDTH/2)-bird_dia/2; /* 300 -20 == 280 and we need 282 
	                                                      282 = 300 bird_ dia/2 so bird_dia should be 36*/
	// Setting y co-ordinate for bird:
	public static int y = GamePanel.HEIGHT/2; // y==400
	
	private static int speed =2;
	private int acce =1;
	
	public BirdImage() {
		LoadImage();
		}

		
		private void LoadImage() {
			
		// TODO Auto-generated method stub
			try {
				img = ImageIO.read(new File("E:\\OOP\\SloppyBird\\Images\\Bird.png"));
				
			}
			catch(Exception e) {
				e.printStackTrace();
			}
		
	}


		// This function draw the bird in game panel
		public void drawBird(Graphics g) {
		// Setting height width and position of bird image:
			g.drawImage(img, x, y, null);
		}
	
		public void birdMovement() { // Call from the game panel class
			if(y>=0 && y<=GamePanel.HEIGHT) {
				speed+=acce; // 3,4,5 going  // -16,-15,-14
				y+=speed;
				// 400+3,400+3+4,400+3+4+5 going downward  // 400-16,400-16-15,400-16-15-14 approaches toward zero y decrease and speed increase
			}
			else {
				
				boolean option = GamePanel.popUpMessage();
				if(option) {
	    			try {
	    				Thread.sleep(500);
	    			}
					catch(Exception e) {
						e.printStackTrace();
					}
	    			
	    			reset();            // if bird touches ground or upper surface than reset the value reset method for upper and lower touch
	    		}
				
    			
	    		else {
	    			// close the window
	    			JFrame frame = MainBird.getWindow();
	    			frame.dispose();
	    			MainBird.timer.stop();
	    			
	    		}
				 
			}
		}

        public void goUpwards() { // Call from GamePanel Class
        	speed=-15; // Initialize the bird upward speed How fast bird should move up.
        }
		public static void reset() { // Call from WallImage class bird reset method
			speed=2;
			y = GamePanel.HEIGHT/2; // y==400
			GamePanel.score=0;
			 GamePanel.GameOver = true;       
			
			
		}
		public static Rectangle getBirdRect() { //Call from Wall Image class;
			Rectangle birdRect = new Rectangle(x,y,45,35); // 35 = height of bird , 45 = width of bird
			return birdRect;                                                                      // ?????????????????????????//
		}
		
		
		

}
