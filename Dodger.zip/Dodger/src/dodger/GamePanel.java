package dodger;


	import java.awt.Font;
	import java.awt.Graphics;
	import java.awt.event.MouseAdapter;
	import java.awt.event.MouseEvent;

	import java.awt.image.BufferedImage;
	import java.io.File;

	import javax.imageio.ImageIO;
	import javax.swing.JOptionPane;
	import javax.swing.JPanel;

	public class GamePanel extends JPanel  {
		/**
		 * 
		 */
		public static boolean starting = false;
		public static int proceed =-1;
		private static final long serialVersionUID = 1L;
		public static int score=0;
		public static boolean GameOver=false;
		public static final int WIDTH = 600;
		public static final int HEIGHT = 800;

		
		// Creating variable for x-coordinate.
		private int xCoor=0;
		private BufferedImage img;  //Change i made 4 tuotorial 
		
		BirdImage bi = new BirdImage(); 
		WallImage wi = new WallImage(GamePanel.WIDTH);  //Setting distance of 600 between two upper walls and bottom
		WallImage wi2 = new WallImage(GamePanel.WIDTH + (GamePanel.WIDTH/2)); /* Than  Setting distance of 900 between two upper walls
		                                                                         and bottom walls   */
		 GamePanel(){
			LoadImage();
			this.addMouseListener(new MouseAdapter() {
				
				public void mousePressed(MouseEvent e) {
					super.mousePressed(e); // Pressed to fire the event
					bi.goUpwards();
				}
				
			});
		}

		private void LoadImage() {
			try {
				img = ImageIO.read(new File("E:\\OOP\\SloppyBird\\Images\\gamePanel.png"));
			}
			catch(Exception e) {
				e.printStackTrace();
			}
			
		}
		public void paint(Graphics g) {
			super.paint(g);
		// Setting  width height and position of image:
			g.drawImage(img, xCoor, 0, null);
			g.drawImage(img, xCoor+2400, 0, null); // Setting GamePanel image after movement of -24000 along x-axis in background
			bi.drawBird(g); // draw bird on game panel
			wi.drawWall(g); // draw 
			wi2.drawWall(g);
			g.setFont(new Font ("Blackadder ITC",Font.BOLD,25));
			g.drawString("SCORE"+ " "+score, 25, 50);
		
			if(starting==true) {
				g.setFont(new Font("Algerian",Font.BOLD,150));
				g.drawString(Integer.toString(proceed),GamePanel.WIDTH/2-75 , 170);
				
			}

		}
		public void Move() {
			bi.birdMovement();   
	// Movements due to these functions:
			wi.wallMovement();   // Call of wall Movement method to move the walls
			wi2.wallMovement(); 
			if(GameOver==true) { // when bird touches wall gameover =true and walls are reset
				wi.X=GamePanel.WIDTH;                        // Use Class name istead of object wi = WallImage//
				wi2.X=GamePanel.WIDTH + (GamePanel.WIDTH/2);
				GameOver=false;
				
				
			}
			// Moving Background image
			xCoor+=WallImage.speed; // -6,-12,-18 ............-2400 moving toward left
			if(xCoor == -2400) { // 2400 distance b/w left most side and start of GamePanel Image which is right most side.
				xCoor=0;
			}
			if(wi.X == BirdImage.x || wi2.X==BirdImage.x) {  //x coordinates of bird image remain same only y co-ordinates changes
				score+=1;
				
			}
			
		}
		public static boolean popUpMessage() {
			int result =JOptionPane.showConfirmDialog(null, "Game Over.Your SCORE is :"+" "+GamePanel.score+"."+" Do you want to restart the Game.", "Game Over", JOptionPane.YES_NO_OPTION);
		    if(result ==JOptionPane.YES_OPTION) {
		    	return true;
		    }
		    else {
		    	return false;
		    }
		
		
		}
}
