package dodger;


	import javax.imageio.ImageIO;
	import javax.swing.JPanel;

	import java.awt.Graphics;
	import java.awt.event.MouseAdapter;
	import java.awt.event.MouseEvent;
	import java.awt.image.BufferedImage;
	import java.io.File;


	public class MenuPanel extends JPanel{

		/**
		 * 
		 */
		
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		/**
		 * 
		 */
		
		// Creating object for Buffered image:
		/*Buffered Image class is sub-class of Image class and used
		  to handle and manipulate the image data made of color model
		  of image data and all buffered image objects have an uper lift
		  corner co-ordinates of (0,0)
		 */
		
		private BufferedImage img = null;
		// variable needed to shift window on click
		public boolean StartingPoint = false;
		// Constructor of menu panel
		 MenuPanel() {
			 // Loading meupanel image:
			 LoadImage();
			 // From this keyword action is added to whole screen
			 this.addMouseListener(new MouseAdapter(){
				 // Mouse adapter class implements MOuselistener class
				// mouseClicked is function of mose adapter having MouseEvent data type parameter
				 // on clicking and release on screen mouseClicked method will invoke:
				 // Mouse Event is a class extends input class
				 public void mouseClicked(MouseEvent e) {
					 // MoseEvents include clicked,presses.drag etc
					 super.mouseClicked(e); /*press then release to fire the event. Call of mouseClicked function where it
					 accept MouseEvent parameter   */
					 // When mouse is clicked StartingPoint is set to true:
					 StartingPoint = true; // Set false above
					
					
					 
					 
			 }
				 
				 
			 });
			 
		 }
		private void LoadImage() {
			try {
				// Giving path of menu panel image
				// Loading image:
				img = ImageIO.read(new File("E:\\OOP\\SloppyBird\\Images\\menuPanel.png")); // Error occurence
			}
			catch(Exception e) {
				e.printStackTrace();
			}
			
			
		}
		public void paint(Graphics g) {
			// Graphics class is provided by Java
			// where g is instance of Graphics class already created
			super.paint(g);
			// Setting height width and position of image:
			g.drawImage(img, 0, 0, GamePanel.WIDTH, GamePanel.HEIGHT, null);
			
		
		}
		
}
