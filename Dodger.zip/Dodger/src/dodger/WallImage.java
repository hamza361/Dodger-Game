package dodger;

import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.Random;

import javax.imageio.ImageIO;

import javax.swing.JFrame;

public class WallImage {
	
	private Random r = new Random();
	public  int X;
	public int Y = r.nextInt(GamePanel.HEIGHT-400)+300; // max =700, min =300; random no. between 0 to 700
	private int width_Wall = 45;
	private int height = GamePanel.HEIGHT-Y ;
	private int gap = 200;
	public static int speed = -6; // Speed of walls
	
	private BufferedImage img = null;
	public WallImage() {
		
	}
	public WallImage(int X) { // Getting X-coordinates for the walls
		this.X = X;  
		LoadImage();
	}
	private void LoadImage() {
		try {
			img = ImageIO.read(new File("E:\\OOP\\SloppyBird\\Images\\Wall.png"));
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	public void drawWall(Graphics g) {
		// Setting height width and position of wall image:
		     g.drawImage(img, X, (-GamePanel.HEIGHT)+(Y-gap), null); // upper wall 600,-800+600-200
			g.drawImage(img, X, Y , null); // bottom wall
			
		}
	
    public void wallMovement() {
    	           // For First wall:
    	X+=speed;  //600-6,600-6-6,600-6-6-6,....,0,...-45   walls are moving back with decrement of -6
    	           // For second Wall:
    	           // 900-6,900-6-6,900-6-6-6,..,0,...-45
    	if(X<=-45) { //Reseting the values of Wall width and height when wall reaches (-45,Y)where 45 is width of wall
    		X=GamePanel.WIDTH;
    		Y= r.nextInt(GamePanel.HEIGHT-400)+200;
    	    height = GamePanel.HEIGHT-Y ;
    	} 
    	
    	Rectangle lowerRect = new Rectangle(X,Y,width_Wall,height);
    	Rectangle upperRect = new Rectangle(X,0,width_Wall,GamePanel.HEIGHT-(height+gap));
    	
    	if(lowerRect.intersects(BirdImage.getBirdRect()) || upperRect.intersects(BirdImage.getBirdRect())){
    		
    		boolean option = GamePanel.popUpMessage();
    		
    		if(option ==true) {
    			try {
        			Thread.sleep(500);
        		}
        		catch(Exception e) {
        			e.printStackTrace();
        			
        		}
        		BirdImage.reset(); //call of bird reset method
        		wall_Reset();  // call of wall rest method
        		
        		
        		
    		}
    		else {
    			// close the window
    			JFrame frame = MainBird.getWindow();
    		
    			frame.dispose();
    		    
    			MainBird.timer.stop();
    			
    		}
    		
    	}
    	
    		
    	
    	
    
    	
    	
    	
    }
   
	private void wall_Reset() {
		// TODO Auto-generated method stub
		Y = r.nextInt(GamePanel.HEIGHT-400)+300;  /* // max =600, min =200;// Both can be remove   1) 
  2) */		height = GamePanel.HEIGHT-Y ;  
            GamePanel.score=0;
            
		GamePanel.GameOver = true;
		
		
	}
	
	
}
