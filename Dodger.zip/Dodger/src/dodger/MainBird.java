package dodger;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.Timer;


public class MainBird {
	

	private static JFrame window;
	public static Timer timer,timer2;
	private int proceed = 4;
	// Constructor to build the window:
	private MainBird() {
		// Initialization of window:
		window = new JFrame();
		// when window is close it terminates the program:
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.setSize(GamePanel.WIDTH, GamePanel.HEIGHT);
		// window popup in the center:
		window.setLocationRelativeTo(null);
		window.setTitle("DODGER");
		// So window does not resize:
		window.setResizable(false);
		// Allow to see the window:
		window.setVisible(true);
		
	}
	private void rendering() { 
	    // Created object for menu panel to call Load image function in menu Panel:
		MenuPanel mp = new MenuPanel();
		// Created object for menu panel to call Load image function in game Panel:
		GamePanel gp = new GamePanel();
		timer = new Timer(20,new ActionListener() {
			
			
            // After every 20 mili seconds timer variable is going to invoke below methods again and again
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				gp.repaint(); // Refering to paint method
				gp.Move(); // Calling Move method again and again in game panel after 20 mili seconds 
			}
			
			
		});
		// Inheriting of JPanel:
		// Adding menu screen:
		window.add(mp);
		// Making menu Screen visible:
		window.setVisible(true);
		// Where while loop is Keeping the menu screen until mouse is clicked:
		while(mp.StartingPoint==false) {
			// Throwing exception because it will sleep for 10 mili seconds
			try {
				Thread.sleep(10);
			}
			catch(Exception e) {
				e.printStackTrace();
			}
		}
		// Removing menu screen:
		window.remove(mp);
		// Adding game screen:
		window.add(gp);
		// Making game screen visible:
		window.setVisible(true);
		window.revalidate();                                                                  
		// Start timer:
		/* Which is going to call the paint method in game panel
		 again and again.Its going to draw / make changes according to the move-
		 ments*/
		// timer.start();
		timer2 = new Timer(1000, new ActionListener() { /* After ever 1000  miliseconds it will perform the
			public void actionPerformed(ActionEvent e) this method and stop when proceed ==0 */
				public void actionPerformed(ActionEvent e) {
					proceed--; //4-1 =3
					GamePanel.proceed=proceed;
					GamePanel.starting=true;
					gp.repaint();
					if(proceed==0) {
						timer2.stop();
					
						timer.start();
						GamePanel.starting=false;
					}
				}
			});
			timer2.start();

		
	} 

	public static void main(String[] args) {
		// Call of default constructor of MainBird to initialize title,screen etc....
		MainBird mb = new MainBird();
		mb.rendering();
	

	}
	public static JFrame getWindow() {
		return window;
	}

}
